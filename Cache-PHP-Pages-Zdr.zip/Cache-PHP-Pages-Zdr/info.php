<?php

include("cachePagesZdr.php");

phpinfo();

$cacheZDR->pageFooter();

?>
