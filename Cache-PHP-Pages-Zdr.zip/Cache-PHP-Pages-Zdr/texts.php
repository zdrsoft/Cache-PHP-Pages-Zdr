"Cache PHP Pages Zdr" - speed up your web site, decrease CPU load on your your 
web hosting account. Improve your web site with this highly improved algorythum. 
Works with dynamic pages and frequently used parameters POST and GET.

If your web hosting provider limits your web hosting account (often the web sites 
uses shared hosting, where persist limitations) by high CPU load, MySQL connections 
per hour or the execution time of your PHP scripts is too long, you could resolve 
this problems and improve productivity of your PHP scripts using this highly 
effective PHP accelerator "Cache PHP Pages Zdr" script is for you. 
The script is appropriate for any kind of sites static and dynamic.


"Cache PHP Pages Zdr" script is free for commercial and non commercial use.
Free download of the script, the script is encrypted. 
If you want profesional installation of the script for your dynamic web site,
please make request in this contact form. The price is 25$ per installation.

Thank you.

REQUIREMENT
============
1. Windows / Unix
2. Apache
3. PHP 5

INSTALLATION
============
1. Copy all files and directories to your installation location
2. Make writeble file /zdr/filesdata.dat
3. Make writeble file /zdr/userdata.dat
4. Make writeble directory /zdr/data/
5. Open file /includez/config.php and edit necessary constants
6. Go to your URL with "Protected Downloads ZDR script"in first login use



DOWNLOAD: Protected Secure Site Area and File Downloads ZDR - restrict your web site files and directories - Free php script

The script "Protected Secure Site Area and File Downloads ZDR" is freeware, please don't remove credit link. 
You can visit forum related to "Protected Secure Site Area and File Downloads ZDR" and get some support.
FORUM: http://www.webtoolbag.com/forum/


